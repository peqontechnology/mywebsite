# Peqon Technology Website

A responsive single-page website for Peqon Technology, designed around the supplied logo.

## Included
- Python Programming
- AI & Machine Learning
- Software Testing
- Software Development
- Course fee: ₹29,999/-
- Email: peqontechnology@gmail.com
- Phone: 93466 06325

## Run
Open `index.html` in any modern browser.

## Customize
- Edit course text in `index.html`
- Edit colors/animations in `style.css`
- Edit interactions in `script.js`
- Replace `logo.png` if you want a different logo
